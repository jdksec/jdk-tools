---
name: False Positive
about: 'Issue for template producing invalid/unexpected result.'
labels: 'false-positive'

---

<!-- ISSUES MISSING IMPORTANT INFORMATION MAY BE CLOSED WITHOUT INVESTIGATION. -->

### Nuclei Version:

<!-- You can find current version of nuclei with "nuclei -version" -->

### Template file:

<!-- Template producing false-positive results, for example: "cves/XX/XX.yaml" -->

### Command to reproduce:

<!-- Please include the command to replicate the behavior so fix can be applied asap. -->
<!-- if host information can not be shared publicly, please reach out to us on discord server in DM -->

### Anything else:
<!-- Links? References? Screnshots? Anything that will give us more context about the issue that you are encountering! -->