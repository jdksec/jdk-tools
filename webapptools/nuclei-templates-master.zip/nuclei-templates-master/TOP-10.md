|    TAG    | COUNT |    AUTHOR     | COUNT |    DIRECTORY     | COUNT | SEVERITY | COUNT |  TYPE   | COUNT |
|-----------|-------|---------------|-------|------------------|-------|----------|-------|---------|-------|
| cve       |  1294 | daffainfo     |   605 | cves             |  1277 | info     |  1352 | http    |  3554 |
| panel     |   591 | dhiyaneshdk   |   503 | exposed-panels   |   600 | high     |   938 | file    |    76 |
| lfi       |   486 | pikpikcu      |   321 | vulnerabilities  |   493 | medium   |   766 | network |    50 |
| xss       |   439 | pdteam        |   269 | technologies     |   266 | critical |   436 | dns     |    17 |
| wordpress |   401 | geeknik       |   187 | exposures        |   254 | low      |   211 |         |       |
| exposure  |   355 | dwisiswant0   |   169 | misconfiguration |   207 | unknown  |     7 |         |       |
| cve2021   |   322 | 0x_akoko      |   154 | token-spray      |   206 |          |       |         |       |
| rce       |   313 | princechaddha |   147 | workflows        |   187 |          |       |         |       |
| wp-plugin |   297 | pussycat0x    |   128 | default-logins   |   101 |          |       |         |       |
| tech      |   282 | gy741         |   126 | file             |    76 |          |       |         |       |
